// Copyright 2021 Manna Harbour
// https://github.com/manna-harbour/miryoku

